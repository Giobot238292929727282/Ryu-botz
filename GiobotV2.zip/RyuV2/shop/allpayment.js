const allpayment = (prefix) => {
return `┏━━━━━━━━━━━━━━━━━━━━
┃                  *PAYMENT*
┣━━━━━━━━━━━━━━━━━━━━
┣━━━⊱❉ *🏧 BANK* ❉⊰━━━━✿
┃  
┣━⊱ *BRI*
┣⊱ BRI ${ownername}
┣━✿ NAMA BRI ${ownername}
┗━━━━━━━━━━━━━━━━━━━━

┏━━━━━━━━━━━━━━━━━━━━
┃                  *PAYMENT*
┣━━━━━━━━━━━━━━━━━━━━
┣━━⊱❉ *💰 E-WALLET* ❉⊰━━━✿
┃   
┣━⊱ *GOPAY*
┣⊱ 0899 0000 0000
┣━━✿ NAMA GOPAY ${ownername}
┃
┣━⊱ *DANA*
┣⊱ 0899 0000 0000
┣━━✿ NAMA DANA ${ownername}
┃
┣━⊱ *PULSA*
┣⊱ 0899 0000 0000
┣━━✿ NAMA PULSA ${ownername}
┃
┗━━━━━━━━━━━━━━━━━━━━

NOTE! : Sebelum melakukan pembayaran ada baiknya anda menghubungi owner terlebih dahulu!
`
	}

exports.allpayment = allpayment
 