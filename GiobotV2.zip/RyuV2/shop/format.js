const format = (prefix) => {
	return `!Salin Pesan Berikut Dan Edit Sesuai Dengan Pesanan Anda

*Format Order 📋*

Id : 
Server :
Nickname :
Jumlah Pesanan :
Harga :
Pembayaran :

Pastikan Id, Server, Dan Nickname 
Anda Benar Karena Jika Pesanan 
Yang Sudah Checkout Namun 
Terjadi Kesalahan Dari Buyer 
Diluar Tanggung Jawab Kami

Terima Kasih 🙏
`
   }

exports.format = format